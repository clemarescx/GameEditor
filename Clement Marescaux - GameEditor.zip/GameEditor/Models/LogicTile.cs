﻿namespace GameEditor{
	public class LogicTile : Tile{
		public int X{ get; set; }
		public int Y{ get; set; }
	}
}