﻿using System.Windows.Media.Imaging;

namespace GameEditor{
	public class Tile{
		public BitmapImage TileImage{ get; set; }
		public string Name{ get; set; }
	}
}