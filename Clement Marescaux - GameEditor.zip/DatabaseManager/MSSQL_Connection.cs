﻿namespace MongodbTest {
	public class MSSQL_Connection{
		public MSSQL_Connection() { }
	}
}